var colors = [
    "FF0000", "FF4500", "FF7F00", "FFBF00", "FFFF00", 
    "BFFF00", "00FF00", "00FF7F", "00FFFF", "007FFF", 
    "0000FF", "4B0082", "9400D3", "BF00FF", "FF00FF", "FF007F"
];
var currentColorIndex = 0;
var a1 = null;

function updateNameColor() {
    var player = Vars.player;

    if (player != null) {
        if (a1 == null) {
            a1 = player.name;
        }

        player.name = "[#" + colors[currentColorIndex] + "]" + a1;
        currentColorIndex = (currentColorIndex + 1) % colors.length;
    }
}

Events.on(EventType.ClientLoadEvent, () => {
    Timer.schedule(updateNameColor, 0, 1);
});